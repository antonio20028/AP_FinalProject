package iiitd.ac.ap_group17.willhero.models;

public class Sword extends Weapon {
    public Sword() {
        super("/assets/weapons/WeaponSword.png");
    }
}
