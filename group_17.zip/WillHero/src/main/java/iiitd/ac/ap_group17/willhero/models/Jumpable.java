package iiitd.ac.ap_group17.willhero.models;

public interface Jumpable {

    void jump();

}
