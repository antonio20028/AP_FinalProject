package iiitd.ac.ap_group17.willhero.models;

public class Obstacle extends RigidiBody {

    public Obstacle(String path) {
        super(path);
    }

}
