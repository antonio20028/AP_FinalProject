package iiitd.ac.ap_group17.willhero.models;

interface Collectable <T> extends Cloneable {

}
