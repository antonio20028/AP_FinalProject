package iiitd.ac.ap_group17.willhero.models;

public class Rocket extends Weapon {

    public Rocket () {
        super("/assets/weapons/WeaponShuriken.png");

    }

}
