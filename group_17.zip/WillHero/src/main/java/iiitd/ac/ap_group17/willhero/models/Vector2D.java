package iiitd.ac.ap_group17.willhero.models;

public class Vector2D {
    private double x;
    private double y;

    public double getX() {
        return x;
    }

    public Vector2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

}
