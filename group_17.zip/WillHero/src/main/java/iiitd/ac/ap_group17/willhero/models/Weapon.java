package iiitd.ac.ap_group17.willhero.models;

public abstract class Weapon extends RigidiBody implements Collectable{
    public Weapon(String path) {
        super(path);
    }
}
